# Sujeet Kumar — Academic Website

This is a simple, responsive personal academic website made with HTML and CSS. It can be hosted for free using GitHub Pages.

## Publish for free with GitHub Pages

1. Create/sign in to a GitHub account at https://github.com/
2. Create a **public** repository named exactly `YOUR-GITHUB-USERNAME.github.io`.
3. Upload `index.html` from this folder to the repository's root.
4. Open the repository's **Settings → Pages**.
5. Under Build and deployment, select **Deploy from a branch**, choose `main` and `/(root)`, then save.
6. After publishing, visit `https://YOUR-GITHUB-USERNAME.github.io/`.

## Before publishing

- Review all biography and education details.
- Complete the publication metadata and distinguish published, accepted, and submitted papers.
- Add Google Scholar, ResearchGate, LinkedIn, and CV links if desired.
- Check the email address and profile links.
- For privacy, do not publish your home address, phone number, or documents containing personal identifiers.

You can edit `index.html` directly on GitHub using the pencil icon. No paid hosting is required. A custom domain, if you choose to buy one, costs extra.
